#!/usr/bin/env python

from breakfast import eggs, toast

eggs("fried")
toast("butter", "strawberry jam")

print()
help(eggs)
print()
help(toast)
