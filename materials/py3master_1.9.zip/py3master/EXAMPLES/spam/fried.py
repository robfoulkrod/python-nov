#!/usr/bin/env python
from spam import logger

def fried_warn():
    logger.warn("in fried!")
