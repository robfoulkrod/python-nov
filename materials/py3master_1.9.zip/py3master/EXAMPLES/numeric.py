#!/usr/bin/env python

a = 5
b = 10
c = 20.22
d = 0o123        # <1>
e = 0xdeadbeef   # <2>
f = 0b10011101   # <3>

print("a, b, c", a, b, c)
print("a + b", a + b)
print("a + c", a + c)
print("d", d)
print("e", e)
print("f", f)
